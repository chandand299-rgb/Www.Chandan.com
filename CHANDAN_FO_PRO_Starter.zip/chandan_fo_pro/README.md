# CHANDAN F&O PRO — starter project

Android-friendly Flask/PWA shell and Windows 10 compatible web app foundation.

## Included
- Login, dashboard, scanner page, CSV upload/preview page
- Dhan credentials are read only from environment variables
- Explicit status that no live data is shown until a verified Dhan adapter exists
- Auto-orders are hard-disabled in this starter
- Experimental scan thresholds: 15m volume 1.5x, OI change 2.0%, score 70/100
- Render deployment blueprint

## Run locally (Windows 10)
1. Install Python 3.11+.
2. Extract ZIP and open Command Prompt in this folder.
3. Run `py -m venv .venv`
4. Run `.venv\\Scripts\\activate`
5. Run `pip install -r requirements.txt`
6. Set environment variables before launching:
   - `set FLASK_SECRET_KEY=use-a-long-random-value`
   - `set ADMIN_USER=chandan`
   - `set ADMIN_PASSWORD=choose-a-strong-password`
   - `set DHAN_CLIENT_ID=your-client-id`
   - `set DHAN_ACCESS_TOKEN=your-token`
7. Run `py app.py` and open `http://127.0.0.1:5000`.

For first local login, if you have not set environment variables, username is `chandan` and password is `change-me-now`. Change this immediately before any network exposure.

## Deploy on Render
1. Upload the project files to a GitHub repository you control.
2. In Render, create a Web Service and connect that repository, or use the included `render.yaml` Blueprint.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Set `ADMIN_PASSWORD`, `FLASK_SECRET_KEY`, `DHAN_CLIENT_ID`, and `DHAN_ACCESS_TOKEN` in Render Environment settings. Do not put real tokens in GitHub.
6. Deploy; Render generates the actual public URL after a successful deployment.

## Important limits
This is a working project foundation, not yet a live trading scanner. The Dhan API market-data adapter, symbol/security-ID mapping, rate-limit handling, and verified historical-data backtest engine still need to be implemented and tested against current Dhan API documentation/permissions. `/api/scan` deliberately returns a clear not-connected/not-implemented response rather than fake live signals. No orders can be placed.
