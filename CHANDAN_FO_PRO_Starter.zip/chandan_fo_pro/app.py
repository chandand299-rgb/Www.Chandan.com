import os, csv, io, json, secrets
from datetime import datetime
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_file, flash

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY') or 'dev-only-change-this-secret-before-public-deploy'
ADMIN_USER = os.environ.get('ADMIN_USER', 'chandan')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'change-me-now')

CONFIG_DEFAULTS = {
    'volume_threshold': 1.5,
    'oi_change_threshold': 2.0,
    'min_score': 70,
    'auto_orders': False,
    'signal_mode': 'BUY/SELL Alert',
}

def dhan_status():
    # Never expose token values to templates or API responses.
    return bool(os.environ.get('DHAN_CLIENT_ID') and os.environ.get('DHAN_ACCESS_TOKEN'))

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapped

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form.get('username', '')
        password = request.form.get('password', '')
        if secrets.compare_digest(user, ADMIN_USER) and secrets.compare_digest(password, ADMIN_PASSWORD):
            session.clear(); session['logged_in'] = True
            return redirect(url_for('dashboard'))
        flash('Login failed. Check username/password.', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear(); return redirect(url_for('login'))

@app.route('/')
def home():
    return redirect(url_for('dashboard') if session.get('logged_in') else url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', dhan_connected=dhan_status(), config=CONFIG_DEFAULTS)

@app.route('/scanner')
@login_required
def scanner():
    return render_template('scanner.html', dhan_connected=dhan_status(), config=CONFIG_DEFAULTS)

@app.route('/api/status')
@login_required
def api_status():
    return jsonify({'app':'CHANDAN F&O PRO','dhan_configured':dhan_status(),'data_mode':'LIVE API CONFIGURED' if dhan_status() else 'NOT CONNECTED — NO LIVE DATA','auto_orders':False,'time':datetime.now().isoformat(timespec='seconds')})

@app.route('/api/scan', methods=['POST'])
@login_required
def scan():
    # Safety-first: this starter does not fabricate live signals. A Dhan market-data adapter
    # must be implemented/verified against the user's current Dhan API entitlement first.
    return jsonify({'ok':False,'mode':'NOT_CONNECTED' if not dhan_status() else 'ADAPTER_NOT_IMPLEMENTED',
                    'message':'No live scan was run. Dhan market-data adapter is not yet connected/verified; no demo rows are presented as live.',
                    'auto_orders':False}), 503

@app.route('/backtest', methods=['GET','POST'])
@login_required
def backtest():
    result = None
    if request.method == 'POST':
        file = request.files.get('csvfile')
        if file and file.filename.lower().endswith('.csv'):
            try:
                text = file.stream.read().decode('utf-8-sig')
                reader = csv.DictReader(io.StringIO(text))
                rows = list(reader)
                result = {'rows':len(rows),'columns':reader.fieldnames or [],'preview':rows[:10],
                          'note':'CSV imported for inspection only. This starter does not claim a validated strategy backtest.'}
            except Exception as e:
                result = {'error':'Could not read CSV: '+str(e)}
        else:
            result = {'error':'Please upload a CSV file.'}
    return render_template('backtest.html', result=result)

@app.route('/manifest.json')
def manifest():
    return jsonify({'name':'CHANDAN F&O PRO','short_name':'F&O PRO','start_url':'/','display':'standalone','background_color':'#0b1020','theme_color':'#10182b','icons':[]})

@app.route('/service-worker.js')
def service_worker():
    return app.send_static_file('service-worker.js')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
